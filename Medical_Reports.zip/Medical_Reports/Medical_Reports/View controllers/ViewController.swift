//
//  ViewController.swift
//  Medical_Reports
//
//  Created by ekincare on 13/12/21.
//

import UIKit

class ViewController: UIViewController {
    
    var selectedIndex = IndexPath()
    var isSelected: Bool = false
    
    @IBOutlet weak var tableview: UITableView!
    
    let yearLabelsArray = ["Jan '20","Feb '20","Mar '20","Apr '20","May '20"]
    let allTimeLabelsArray = ["'16","'17","'18","'19","'20"]
    let yearsRbcCount = [5.86,2.8,4.4,3.0,5.2]
    let allTimeRbcCount = [3.6,6.2,2.4,4.8,5.8]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableview.delegate = self
        tableview.dataSource = self
        tableview.rowHeight = UITableView.automaticDimension
        tableview.estimatedRowHeight = 350
        
        regCell()
    }
    
    func regCell() {
        self.tableview.register(BlackCell.nib(), forCellReuseIdentifier: BlackCell.identifier)
        self.tableview.register(FirstCell.nib(), forCellReuseIdentifier: FirstCell.identifier)
        self.tableview.register(SecondCell.nib(), forCellReuseIdentifier: SecondCell.identifier)
        self.tableview.register(ThirdCell.nib(), forCellReuseIdentifier: ThirdCell.identifier)
        self.tableview.register(FourthCell.nib(), forCellReuseIdentifier: FourthCell.identifier)
        self.tableview.register(FifthCell.nib(), forCellReuseIdentifier: FifthCell.identifier)
    }
}
// MARK: -  Delegate Methods

extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch indexPath.row {
        case 0:
            return 337
        case 1:
            return 20
        case 2:
            if self.selectedIndex == indexPath && isSelected == true {
                return 188
            } else {
                return 66
            }
        case 3:
            return 56
        case 4:
            return 56
        default:
            return UITableView.automaticDimension
        }
    }
}
// MARK: - DataSource Methods

extension ViewController: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 7
        
       
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cellSetup(indexPath: indexPath)
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        didSelectRow(indexPath: indexPath)
    }
    
// MARK:- CELLFORROW

    func cellSetup(indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            if let cell = tableview.dequeueReusableCell(withIdentifier: "FirstCell", for: indexPath) as? FirstCell {
                cell.yearLabels = yearLabelsArray
                cell.allTimeLabels = allTimeLabelsArray
                cell.rbcAllTimeCount = allTimeRbcCount
                cell.rbcYearCount = yearsRbcCount
                
                return cell
            }
        } else if indexPath.row == 1 {
            if let cell = tableview.dequeueReusableCell(withIdentifier: "SecondCell", for: indexPath) as? SecondCell {
                return cell
            }

        } else if indexPath.row == 2 {
            if let cell = tableview.dequeueReusableCell(withIdentifier: "ThirdCell", for: indexPath) as? ThirdCell {
                return cell
            }

        }else if indexPath.row == 3 {
            if let cell = tableview.dequeueReusableCell(withIdentifier: "FourthCell", for: indexPath) as? FourthCell {
                return cell
            }
        } else if indexPath.row > 3 {
            if let cell = tableview.dequeueReusableCell(withIdentifier: "FifthCell", for: indexPath) as? FifthCell {
                return cell
            }
        } else {
            return UITableViewCell()
        }
        return UITableViewCell()
    }
    
// MARK:- DIDSELECTROW
    func didSelectRow(indexPath: IndexPath) {
        
        if indexPath.row == 2 {
            if selectedIndex == indexPath {
                if isSelected == false {
                    self.isSelected = true
                    if let cell = tableview.cellForRow(at: indexPath) as? ThirdCell {
                        cell.configure(image: UIImage(named: "uparrow")!)
                        cell.animate()

                    }

                } else {
                    if let cell = tableview.cellForRow(at: indexPath) as? ThirdCell {
                        cell.configure(image: UIImage(named: "Downarrow")!)
                    }
                    self.isSelected = false
                }
            } else {
                self.isSelected = true
                if let cell = tableview.cellForRow(at: indexPath) as? ThirdCell {
                    cell.configure(image: UIImage(named: "uparrow")!)
                    cell.animate()

                }
            }
            self.selectedIndex = indexPath
            UIView.animate(withDuration: 0.3) {
                self.tableview.performBatchUpdates(nil)
            }
        }
        tableview.deselectRow(at: indexPath, animated: false)
    }

}


