//
//  ThirdCell.swift
//  Medical_Reports
//
//  Created by ekincare on 13/12/21.
//

import UIKit

class ThirdCell: UITableViewCell {

    @IBOutlet weak var rbcCountTitle: UILabel!
    @IBOutlet weak var btnClicked: UIButton!
    @IBOutlet weak var descLbl: UILabel!
        
    static let identifier = "ThirdCell"
    static func nib() -> UINib {
        return UINib(nibName: "ThirdCell", bundle: nil)
    }
    
    public func configure(image: UIImage) {
        btnClicked.setImage(image, for: .normal)
    }
    var paragraphStyle = NSMutableParagraphStyle()

    
    override func awakeFromNib() {
        super.awakeFromNib()
        paragraphStyle.lineHeightMultiple = 1.71
        descLbl.attributedText = NSMutableAttributedString(string: "An RBC count is a blood test that measures how\nmany red blood cells (RBCs) you have. RBCs contain\nhemoglobin , which carries oxygen. How much\noxygen your body tissues get depends on how many\nRBCs you have and how well they work.", attributes: [NSAttributedString.Key.paragraphStyle: paragraphStyle])
        
        
    }

    @IBAction func btnClickedAction(_ sender: UIButton) {

    }
    
    func animate() {
          UIView.animate(withDuration: 0.5, delay: 0.3, usingSpringWithDamping: 0.8, initialSpringVelocity: 1, options: .curveLinear, animations: {
              self.contentView.layoutIfNeeded()
          }, completion: nil)
      }
    
}
