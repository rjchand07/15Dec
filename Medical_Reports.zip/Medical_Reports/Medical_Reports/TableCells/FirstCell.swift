//
//  FirstCell.swift
//  Medical_Reports
//
//  Created by ekincare on 13/12/21.
//

import UIKit
import Charts

class FirstCell: UITableViewCell {
    
    @IBOutlet weak var lineChartView: LineChartView!
    @IBOutlet weak var RBCCountLbl: UILabel!
    @IBOutlet weak var dateLbl: UILabel!
    @IBOutlet weak var rangeLbl: UILabel!
    
    @IBOutlet weak var segmentControlLabel: UISegmentedControl!
    
    static let identifier = "FirstCell"
    static func nib() -> UINib {
        return UINib(nibName: "FirstCell", bundle: nil)

    }
    
    var yearLabels = [String]()
    var allTimeLabels = [String]()
    var rbcAllTimeCount = [Double]()
    var rbcYearCount = [Double]()
    
    let allTimeSetColor = UIColor(red: 1, green: 0.711, blue: 0, alpha: 1)
    let yearSetColor = UIColor(red: 0.247, green: 0.796, blue: 0.498, alpha: 1)
    
    override func awakeFromNib() {
        super.awakeFromNib()
        segmentControlLabel.font(name: "ProximaNova-Semibold", size: 12)

        setChart(values: allTimeLabels, indexes: rbcAllTimeCount)
        setupChart()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    @IBAction func segmentedControl(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex {
        case 0:
            setChart(values: allTimeLabels, indexes: rbcAllTimeCount)
            setupChart()
        case 1:
            setChart(values: yearLabels, indexes: rbcYearCount)
            setupChart()
        default:
            setChart(values: allTimeLabels, indexes: rbcAllTimeCount)
            setupChart()
        }
    }
    
// MARK: - Setting up chart
    
    func setChart(values: [String], indexes: [Double]) {
        // Setting Values
            var dataEntries: [ChartDataEntry] = []
            
            for i in 0..<values.count {
                let dataEntry = ChartDataEntry(x: Double(i), y: indexes[i])
                dataEntries.append(dataEntry)
            }
        // Colors
        let red = Double(arc4random_uniform(256))
            let green = Double(arc4random_uniform(256))
            let blue = Double(arc4random_uniform(256))
            let colors = UIColor(red: CGFloat(red/255), green: CGFloat(green/255), blue: CGFloat(blue/255), alpha: 1)
        
        let set = LineChartDataSet(entries: dataEntries, label: "")
        set.setColor(colors)
        
        let data = LineChartData(dataSet: set)
        
        self.lineChartView.data = data
        
        lineChartView.xAxis.valueFormatter = IndexAxisValueFormatter(values: values)
        lineChartView.xAxis.granularity = 1
        
    }
    
    func setupChart() {
        
        lineChartView.backgroundColor = .white
        lineChartView.leftAxis.enabled = false
        
        let yAxis = lineChartView.rightAxis
        yAxis.setLabelCount(4, force: false)
        yAxis.axisLineColor = UIColor(red: 0.898, green: 0.91, blue: 0.941, alpha: 1)
        yAxis.labelTextColor = UIColor(red: 0.533, green: 0.584, blue: 0.686, alpha: 1)
        yAxis.gridColor = UIColor(red: 0.898, green: 0.91, blue: 0.941, alpha: 1)
        
        lineChartView.xAxis.drawGridLinesEnabled = false
        lineChartView.xAxis.labelPosition = .bottom
        lineChartView.xAxis.setLabelCount(6, force: false)
        lineChartView.xAxis.axisLineColor = UIColor(red: 0.898, green: 0.91, blue: 0.941, alpha: 1)
        lineChartView.xAxis.labelTextColor = UIColor(red: 0.533, green: 0.584, blue: 0.686, alpha: 1)
        
    }
}
// MARK: - Extension

extension UISegmentedControl {
    func font(name:String?, size:CGFloat?) {
        let attributedSegmentFont = NSDictionary(object: UIFont(name: name!, size: size!)!, forKey: NSAttributedString.Key.font as NSCopying)
        setTitleTextAttributes(attributedSegmentFont as [NSObject : AnyObject] as [NSObject : AnyObject] as? [NSAttributedString.Key : Any], for: .normal)
    }
}


class XAxisValueFormatter: NSObject, IAxisValueFormatter {

    func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        let dateFormatterPrint = DateFormatter()
        dateFormatterPrint.dateFormat = "HH:mm:ss"

        let date = Date(timeIntervalSince1970: value)
        let time = dateFormatterPrint.string(from: date)

            return time
      }
}

