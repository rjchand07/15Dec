//
//  FifthCell.swift
//  Medical_Reports
//
//  Created by ekincare on 13/12/21.
//

import UIKit

class FifthCell: UITableViewCell {

    @IBOutlet weak var dateLbl: UILabel!
    @IBOutlet weak var rbcCountLbl: UILabel!
    static let identifier = "FifthCell"
    static func nib() -> UINib {
        return UINib(nibName: "FifthCell", bundle: nil)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}
